package org.springframework.security.extension.authentication;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Rest 模式登录认证绑定的参数对象Model
 * @author [@Loong Wan](https://github.com/loong10k)
 */
public class PostLoginRequest {
	
	/**
	 * 认证账号（必选）
	 */
    private String username;
    /**
   	 * 认证密码（必选）
   	 */
    private String password;
    /**
   	 * 验证码（可选）
   	 */
    private String captcha;
	
    @JsonCreator
    public PostLoginRequest(@JsonProperty("username") String username, @JsonProperty("password") String password, @JsonProperty("captcha") String captcha) {
        this.username = username;
        this.password = password;
        this.captcha = captcha;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

	public String getCaptcha() {
		return captcha;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
